﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wealthmanagementsusyem
{
    public partial class Funds : Form
    {
        String Connection = "Data Source=DESKTOP-AND0HQB;Initial Catalog=WealthManagementSystem;Integrated Security=True";
        public Funds()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Investment Plan 1")
            {
                textBox3.Text = "0.05";
            }
            else if (comboBox1.Text == "Investment Plan 2")
            {
                textBox3.Text = "0.03";
            }
            else if (comboBox1.Text == "Investment Plan 3")
            {
                textBox3.Text = "0.1";
            }
            else if (comboBox1.Text == "Investment Plan 4")
            {
                textBox3.Text = "0.07";
            }
            else if (comboBox1.Text == "Investment Plan 5")
            {
                textBox3.Text = "0.04";
            }
            else if (comboBox1.Text == "Investment Plan 6")
            {
                textBox3.Text = "0.08";
            }
            else if (comboBox1.Text == "Investment Plan 7")
            {
                textBox3.Text = "0.1";
            }
            else if (comboBox1.Text == "Investment Plan 8")
            {
                textBox3.Text = "0.06";
            }
            else if (comboBox1.Text == "Investment Plan 9")
            {
                textBox3.Text = "0.05";
            }
            else if (comboBox1.Text == "Investment Plan 10")
            {
                textBox3.Text = "0.02";
            }
            else
            {
                textBox3.Text = "0.00";
            }
        }

        private void Funds_Load(object sender, EventArgs e)
        {
            textBox1.Text = "0.00";
            textBox2.Text = "0.00";
            textBox3.Text = "0.00";
            textBox4.Text = "0.00";

            String query = "Select ClientID from Clients";
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            
            while (reader.Read())
            {
                comboBox2.Items.Add(reader.GetInt32(0).ToString());
            }
            reader.Close();
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int year;
            double invamount, rate,interest,totalamount;

            invamount = Convert.ToDouble(textBox1.Text);
            year = Convert.ToInt32(textBox2.Text);
            rate = Convert.ToDouble(textBox3.Text);

            interest = invamount * year * rate;
            totalamount = invamount + interest;

            textBox4.Text = totalamount.ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            String query = "Insert into Investers values("+ comboBox2.Text + "," + "'" + comboBox1.Text + "'" + "," + "'" + textBox1.Text + "'" + "," + "'" + textBox3.Text + "'" + "," + textBox2.Text + "," + "'" + textBox4.Text + "'" + ")";
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            int result = cmd.ExecuteNonQuery();
            if (result == 1)
            {
                DialogResult dialogResult = MessageBox.Show("Investment Added Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                DialogResult dialogResult = MessageBox.Show("Failed Add This Investment Please Try Again...):", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            con.Close();
        }
    }
}
