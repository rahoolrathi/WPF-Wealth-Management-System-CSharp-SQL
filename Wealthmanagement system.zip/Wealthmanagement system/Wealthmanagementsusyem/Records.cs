﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wealthmanagementsusyem
{
    public partial class Records : Form
    {
        String Connection = "Data Source=DESKTOP-AND0HQB;Initial Catalog=WealthManagementSystem;Integrated Security=True";
        public Records()
        {
            InitializeComponent();
        }

        private void Records_Load(object sender, EventArgs e)
        {
            listView1.GridLines = true;
            String query = "select Sr#,ClientID,Plans,Investamt,interest,years,profit from Investers";
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            listView1.Items.Clear();
            while (reader.Read())
            {
                ListViewItem item = new ListViewItem(reader.GetInt32(0).ToString());
                item.SubItems.Add(reader.GetInt32(1).ToString());
                item.SubItems.Add(reader.GetString(2));
                item.SubItems.Add(reader.GetString(3));
                item.SubItems.Add(reader.GetString(4));
                item.SubItems.Add(reader.GetInt32(5).ToString());
                item.SubItems.Add(reader.GetString(6));
                listView1.Items.Add(item);
            }
            reader.Close();
            con.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            String query = "select Sr#,ClientID,Plans,Investamt,interest,years,profit from Investers";
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            listView1.Items.Clear();
            while (reader.Read())
            {
                ListViewItem item = new ListViewItem(reader.GetInt32(0).ToString());
                item.SubItems.Add(reader.GetInt32(1).ToString());
                item.SubItems.Add(reader.GetString(2));
                item.SubItems.Add(reader.GetString(3));
                item.SubItems.Add(reader.GetString(4));
                item.SubItems.Add(reader.GetInt32(5).ToString());
                item.SubItems.Add(reader.GetString(6));
                listView1.Items.Add(item);
            }
            reader.Close();
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < listView1.Items.Count; i++)
            {
                if (listView1.Items[i].Selected)
                {
                    string item = listView1.SelectedItems[0].Text;
                    int index = Convert.ToInt32(item);
                    String query = "Delete from Investers where Sr# =" + index;
                    SqlConnection con = new SqlConnection(Connection);
                    con.Open();
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    listView1.Items[i].Remove();
                    i--;
                }
            }
        }
    }
}
