﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wealthmanagementsusyem
{
    public partial class Login : Form
    {
        String Connection = "Data Source=DESKTOP-AND0HQB;Initial Catalog=WealthManagementSystem;Integrated Security=True";
        public Login()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String query = "Select count(*)  as cnt from Employees where Email ='"+textBox1.Text +"'and Password ='"+textBox2.Text+"'";
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            if (cmd.ExecuteScalar().ToString() == "1")
            {
                this.Hide();
                Dashboard obj = new Dashboard();
                obj.Show();
                DialogResult dialogResult = MessageBox.Show("Successfullt Login ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                DialogResult dialogResult = MessageBox.Show("Invalid User name or Password", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Registration reg = new Registration();
            this.Hide();
            reg.Show();
        }
    }
}
