﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wealthmanagementsusyem
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Employees_List emplist = new Employees_List()
            { 
                Dock = DockStyle.Fill, 
                TopLevel = false,
                TopMost = true
            };
            this.formcontainer.Controls.Add(emplist);
            emplist.Show();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Client_List cllist = new Client_List()
            {
                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };
            this.formcontainer.Controls.Add(cllist);
            cllist.Show();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            Funds fnd = new Funds()
            {
                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };
            this.formcontainer.Controls.Add(fnd);
            fnd.Show();
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            Investment inst = new Investment()
            {
                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };
            this.formcontainer.Controls.Add(inst);
            inst.Show();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Records rec = new Records()
            {
                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };
            this.formcontainer.Controls.Add(rec);
            rec.Show();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            Complaints comp = new Complaints()
            {
                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };
            this.formcontainer.Controls.Add(comp);
            comp.Show();
        }
    }
}
