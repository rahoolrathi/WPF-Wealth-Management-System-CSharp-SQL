﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wealthmanagementsusyem
{
    public partial class Registration : Form
    {
        String Connection = "Data Source=DESKTOP-AND0HQB;Initial Catalog=WealthManagementSystem;Integrated Security=True";
        String Gender;
        public Registration()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (radioButton1.Checked)
            {
                Gender = "Male";
            }
            else if (radioButton2.Checked)
            {
                Gender = "Female";
            }
            String query = "Insert into Employees values("+textBox1.Text+","+"'"+textBox2.Text+ "'" + "," + "'" + textBox3.Text + "'" + "," + "'" + textBox4.Text + "'" + "," + "'" + textBox5.Text + "'" + "," + "'" + Gender + "'" + "," + "'" + textBox6.Text + "'" + "," + "'" + textBox7.Text + "'"+")";
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            int result = cmd.ExecuteNonQuery();
            if (result == 1)
            {
                DialogResult dialogResult = MessageBox.Show("You are Registered Successfully", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Login lgn = new Login();
                this.Hide();
                lgn.Show();
            }
            else
            {
                DialogResult dialogResult = MessageBox.Show("Registration Failed...", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            con.Close();
        }
    }
}
