﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Wealthmanagementsusyem
{
    public partial class Employees_List : Form
    {
        String Connection = "Data Source=DESKTOP-AND0HQB;Initial Catalog=WealthManagementSystem;Integrated Security=True";
        public Employees_List()
        {
            InitializeComponent();
        }


        private void Employees_List_Load(object sender, EventArgs e)
        {
            listView1.GridLines = true;
            String query = "select Sr#,EmployeeID,First_name, Last_name,Email,Phone,Gender,Address from Employees";
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            SqlCommand cmd = new SqlCommand(query,con);
            SqlDataReader reader = cmd.ExecuteReader();
            listView1.Items.Clear();
            while (reader.Read())
            {
                ListViewItem item = new ListViewItem(reader.GetInt32(0).ToString());
                item.SubItems.Add(reader.GetInt32(1).ToString());
                item.SubItems.Add(reader.GetString(2));
                item.SubItems.Add(reader.GetString(3));
                item.SubItems.Add(reader.GetString(4));
                item.SubItems.Add(reader.GetString(5));
                item.SubItems.Add(reader.GetString(6));
                item.SubItems.Add(reader.GetString(7));
                listView1.Items.Add(item);
            }
            reader.Close();
            con.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < listView1.Items.Count; i++)
            {
                if (listView1.Items[i].Selected)
                {
                    string item = listView1.SelectedItems[0].Text;
                    int index = Convert.ToInt32(item);  
                    String query = "Delete from Employees where Sr# =" + index;
                    SqlConnection con = new SqlConnection(Connection);
                    con.Open();
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    listView1.Items[i].Remove();
                    i--;
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            String query = "select Sr#,EmployeeID,First_name, Last_name,Email,Phone,Gender,Address from Employees";
            SqlConnection con = new SqlConnection(Connection);
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader reader = cmd.ExecuteReader();
            listView1.Items.Clear();
            while (reader.Read())
            {
                ListViewItem item = new ListViewItem(reader.GetInt32(0).ToString());
                item.SubItems.Add(reader.GetInt32(1).ToString());
                item.SubItems.Add(reader.GetString(2));
                item.SubItems.Add(reader.GetString(3));
                item.SubItems.Add(reader.GetString(4));
                item.SubItems.Add(reader.GetString(5));
                item.SubItems.Add(reader.GetString(6));
                item.SubItems.Add(reader.GetString(7));
                listView1.Items.Add(item);
            }
            reader.Close();
            con.Close();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < listView1.Items.Count; i++)
            {
                if (listView1.Items[i].Selected)
                {
                    int srnum =Convert.ToInt32(listView1.Items[i].SubItems[0].Text);
                    int empid = Convert.ToInt32(listView1.Items[i].SubItems[1].Text);
                    String fname = listView1.Items[i].SubItems[2].Text;
                    String lname = listView1.Items[i].SubItems[3].Text;
                    String email = listView1.Items[i].SubItems[4].Text;
                    String phone = listView1.Items[i].SubItems[5].Text;
                    String gender = listView1.Items[i].SubItems[6].Text;
                    String address = listView1.Items[i].SubItems[7].Text;

                    String Data = "Sr#: " + srnum + "\nEmployeeID: " + empid + "\nFirst Name: " + fname + "\nLast Name: " + lname + "\nEmail: " + email + "\nPhone: " + phone + "\nGender: " + gender + "\nAddress: " + address;
                    MessageBox.Show(Data,"Employees Information",MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
    }
}
