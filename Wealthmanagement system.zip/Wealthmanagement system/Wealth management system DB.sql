Create Database WealthManagementSystem

Use WealthManagementSystem

Create Table Employees
(
Sr# int identity(1,1) primary key,
EmployeeID int not Null,
First_name varchar(30),
Last_name varchar(30),
Email varchar(50),
Phone varchar(20),
Gender varchar(20),
Address varchar(100),
Password varchar(30)
)
 delete from Employees where Sr# = 7
select Sr#,EmployeeID,First_name, Last_name,Email,Phone,Gender,Address,Password from Employees

Select count(*)  as cnt from Employees where Email = 'ali@gmail.com' and Password = '12345'

 Insert into Employees values
 (1000,'Zeeshan','Asghar','codewithzeeshan@gmail.com','+92 3479479501', 'Male','H# 38 millat Street jarahi stop Adyala road Rawalpindi Pakistan','123abc'),
 (1001,'Rahul','Khan','Rahul123@gmail.com','+91 3479479501', 'Male','H# 38 millat Street jarahi stop Adyala road Rawalpindi India','admin'),
 (1002,'Sharol','Aziz','sharol@gmail.com','+256 3479479501', 'Female','H# 38 millat Street jarahi stop Adyala road Rawalpindi Canada','123456')

 Create Table Clients
(
Sr# int identity(1,1) primary key,
ClientID int not Null,
First_name varchar(30),
Last_name varchar(30),
Email varchar(50),
Phone varchar(20),
Gender varchar(20),
Address varchar(100),
)

select Sr#,ClientID,First_name, Last_name,Email,Phone,Gender,Address from Clients

Insert into Clients values
 (1000,'Zeeshan','Asghar','codewithzeeshan@gmail.com','+92 3479479501', 'Male','H# 38 millat Street jarahi stop Adyala road Rawalpindi Pakistan'),
 (1001,'Rahul','Khan','Rahul123@gmail.com','+91 3479479501', 'Male','H# 38 millat Street jarahi stop Adyala road Rawalpindi India'),
 (1002,'Sharol','Aziz','sharol@gmail.com','+256 3479479501', 'Female','H# 38 millat Street jarahi stop Adyala road Rawalpindi Canada')

Create Table Complains
(
Sr# int identity(1,1) primary key,
ClientID int,
complains varchar(300)
)

Select * from Complains
Insert into Complains values
 (1000,'ertyuiortyuioertyuiowertyuioetyuioetyuioertyuioertyuioertyuietyuirtyuiertyuiertyuirtyuirtyurtyuertyuiertyuertyurtyuertyu')

Create Table Investers
(
Sr# int identity(1,1) primary key,
ClientID int not Null,
Plans varchar(50),
Investamt varchar(50),
interest varchar(20),
years int,
profit varchar(50)
)
Insert into Investers values
 (1034,'Investment plan 6','23000','0.05',7,'67550')